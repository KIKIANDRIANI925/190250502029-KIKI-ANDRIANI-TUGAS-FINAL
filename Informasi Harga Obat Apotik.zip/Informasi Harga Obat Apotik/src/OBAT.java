
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kiki
 */
public class OBAT {
    public static void main(String[] args){
        BufferedReader dataIn = new BufferedReader (new InputStreamReader (System.in));
        Daftar_Harga Harga = new Daftar_Harga();
        try
        { 
            System.out.println("          DAFTAR OBAT APOTIK          ");
            System.out.println("==========================================");
            System.out.println("Acarbose");
            System.out.println("Albumin");
            System.out.println("Allopurinol");
            System.out.println("Alprazolam");
            System.out.println("Ambroxol");
            System.out.println("Amfetamin");
            System.out.println("Amikacin");
            System.out.println("Amil Nitrit");
            System.out.println("Amilase");
            System.out.println("Aminofilin");
            System.out.println("Amonium Klorida");
            System.out.println("Amoxicillin");
            System.out.println("Ampicillin");
            System.out.println("Antihistamin");
            System.out.println("Antijamur");
            System.out.println("Arginine");
            System.out.println("Asam Alginat");
            System.out.println("Asam Borat");
            System.out.println("Asam Glikolat");
            System.out.println("Aspirin");
            System.out.println("Atenolol");
            System.out.println("Atorvastatin");
            System.out.println("Atropin");
            System.out.println("Biotin");
            System.out.println("Bisoprolol");
            System.out.println("Busulfan");
            System.out.println("Cefixime");
            System.out.println("CetiriZine");
            System.out.println("Cisapride");
            System.out.println("Clobazam");
            System.out.println("Diazepam");
            System.out.println("Digoxin");
            System.out.println("Diuretik");
            System.out.println("Dobutamin");
            System.out.println("Estrogen");
            System.out.println("Estradiol");
            System.out.println("Eperisone");
            System.out.println("Entrostop");
            System.out.println("Furosemide");
            System.out.println("Fucoidan");
            System.out.println("Gentamicin");
            System.out.println("Gliserol");
            System.out.println("Heparin");
            System.out.println("Indinavir");
            System.out.println("ketemine");
            System.out.println("Ketamine");
            System.out.println("Lanolin");
            System.out.println("Levodopa");
            System.out.println("Manitol");
            System.out.println("Metildopa");
            System.out.println("Morfin");
            System.out.println("Nystatin");
            System.out.println("Orlistat");
            System.out.println("Panadol");
            System.out.println("Penesilin");
            System.out.println("Petrolatum");
            System.out.println("Piracetam");
            System.out.println("Ponstan");
            System.out.println("Ramipril");
            System.out.println("Senna");
            System.out.println("Tamoxifen");
            System.out.println("Vitamin A");
            System.out.println("Vitamin C");
            System.out.println("Vitamin D");
            System.out.println("Vitamin E");
            System.out.println("Vitamin K");
            System.out.println("Keluar");
            System.out.println("============================");
            System.out.println("Masukkan Nama Obat");
            Harga.PilihOBAT();
        }
        catch (Exception e){
            e.printStackTrace();
    }
    }
    
}
