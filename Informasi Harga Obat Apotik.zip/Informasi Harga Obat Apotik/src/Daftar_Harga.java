
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kiki
 */
public class Daftar_Harga {
    private String OBAT;
    
    void PilihOBAT (){
        Scanner input = new Scanner (System.in);
        String pilih ;
        
        for (int i = 0; i <= 10 ; i++) {
        pilih = input.nextLine();
        switch (pilih){
            case "Acarbose" :
                  System.out.println("==================");
                  System.out.println("< Acarbose >");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.21.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.10.000");
                  System.out.println("==================");
                   break;
            case "Albumin" :
                  System.out.println("==================");
                  System.out.println("< Albumin >");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.12.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.2.000");
                  System.out.println("==================");
                  break;
            case "Allopurinol" :
                  System.out.println("==================");
                  System.out.println("< Allopurinol >");
                   System.out.println("Harga Pertablet");
                  System.out.println("Rp.14.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.3.000");
                  System.out.println("==================");
                  break;
            case "Alprazolam" :
                  System.out.println("==================");
                  System.out.println("< Alprazola >");
                   System.out.println("Harga Pertablet");
                  System.out.println("Rp.15.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.4.000");
                  System.out.println("==================");
                  break;
            case "Ambroxol" :
                  System.out.println("< Ambroxol >");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.5.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.1.000");
                  break;
            case "Amfetamin" :
                  System.out.println("==================");
                  System.out.println("< Amfetamin >");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.19.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.7.000");
                  System.out.println("==================");
                  break;
            case "Amikacin" :
                  System.out.println(" < Amikacin >");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.20.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.6.000");
                  break;
            case "Amil Nitrit" :
                  System.out.println("==================");
                  System.out.println("< Amil Nitrit >");
                   System.out.println("Harga Pertablet");
                  System.out.println("Rp.3.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.500");
                  System.out.println("==================");
                  break;   
            case "Amilase" :
                  System.out.println("==================");
                  System.out.println("< Amilas >");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.4.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.500");
                  System.out.println("==================");
                  break;
            case "Aminofilin" :
                  System.out.println("==================");
                  System.out.println("< Aminofilin >");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.5.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.1.000");
                  System.out.println("==================");
                  break;
             case "Amoxicillin" :
                  System.out.println("==================");
                  System.out.println(" < Amoxicillin >");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.9.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.2.000");
                  System.out.println("==================");
                  break;
            case "Ampicillin" :
                  System.out.println("==================");
                  System.out.println("< Ampicillin >");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.20.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.3.000");
                  System.out.println("==================");
                  break;
            case "Antnihistami" :
                  System.out.println("==================");
                  System.out.println(" < Antnihistami >");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.5.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.1.000");
                  System.out.println("==================");
                  break;
            case "Antijamur" :
                  System.out.println("==================");
                  System.out.println(" < Antijamur >");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.8.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.2.000");
                  System.out.println("==================");
                  break;
           case "Arginine" :
                  System.out.println("==================");
                  System.out.println("Arginine");
                 System.out.println("Harga Pertablet");
                  System.out.println("Rp.2.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.500");
                  System.out.println("==================");
                  break;
            case "Asam Alginat" :
                  System.out.println("==================");
                  System.out.println("< Asam Alginat >");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.2.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.500");
                  System.out.println("==================");
                  break;
           case "Asam Borat" :
                  System.out.println("==================");
                  System.out.println("< Asam Borat >");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.6.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.1.000");
                  System.out.println("==================");
                  break;
            case "Asam Glikolat" :
                  System.out.println("==================");
                  System.out.println("< Asam Glikolat >");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.30.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.5.000");
                  System.out.println("==================");
                  break;
             case "Aspirin" :
                  System.out.println("==================");
                  System.out.println("Aspirin");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.29.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.6.000");
                  System.out.println("==================");
                  break;
            case "Atenolol" :
                  System.out.println("==================");
                  System.out.println("Atenolol");
                 System.out.println("Harga Pertablet");
                  System.out.println("Rp.21.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.6.000");
                  System.out.println("==================");
                  break;
            case "Atorvastatin" :
                  System.out.println("==================");
                  System.out.println("Atorvastatin");
                 System.out.println("Harga Pertablet");
                  System.out.println("Rp.2.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.500");
                  System.out.println("==================");
                  break;
            case "Atropin" :
                  System.out.println("Atropin");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.1.000");
                  break;
            case "Biotin" :
                  System.out.println("==================");
                  System.out.println("Biotin");
                  System.out.println("Rp.9.000");
                  System.out.println("==================");
                  break;
            case "Bisoprolol" :
                  System.out.println("==================");
                  System.out.println("Bisoprolol");
                  System.out.println("Rp.1.000");
                  System.out.println("==================");
                  break;
            case "Busulfan" :
                  System.out.println("==================");
                  System.out.println("Busulfan");
                  System.out.println("Rp.9.000");
                  System.out.println("==================");
                  break;
            case "Cefixime" :
                  System.out.println("==================");
                  System.out.println("Cefixime");
                  System.out.println("Rp.6.000");
                  System.out.println("==================");
                  break;
            case "CetiriZinee" :
                  System.out.println("==================");
                  System.out.println("CetiriZinee");
                  System.out.println("Rp.12.000");
                  System.out.println("==================");
                  break;
            case "Cisapride" :
                  System.out.println("==================");
                  System.out.println("< Cisapride");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.9.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.3.000");
                  System.out.println("==================");
                  break;
            case "Clobazam" :
                  System.out.println("==================");
                  System.out.println("< Clobazam");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.21.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.10.000");
                  System.out.println("==================");
                  break;
            case "Diazepam" :
                  System.out.println("==================");
                  System.out.println("< Diazepam");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.22.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.10.000");
                  System.out.println("==================");
                  break;
            case "Digoxin" :
                  System.out.println("==================");
                  System.out.println("< Digoxin");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.24.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.12.000");
                  System.out.println("==================");
                  break;
            case "Diuretik" :
                  System.out.println("==================");
                  System.out.println("Diuretik");
                  System.out.println("< Digoxin");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.15.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.3.000");
                  System.out.println("==================");
                  break;
            case "Dobutamin" :
                  System.out.println("==================");
                  System.out.println("Dobutamin");
                   System.out.println("< Digoxin");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.18.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp6.000");
                  System.out.println("==================");
                  break;
            case "Estrogen" :
                  System.out.println("==================");
                  System.out.println("< Estrogen");
                  System.out.println("Harga Pertablet");
                  System.out.println("Rp.12.000");
                  System.out.println("Harga Perkapsul");
                  System.out.println("Rp.000");
                  System.out.println("==================");
                  break;
            case "Estradiol" :
                  System.out.println("==================");
                  System.out.println("Estradiol");
                  System.out.println("Rp.11.000");
                  System.out.println("==================");
                  break;
            case "Eperisone" :
                  System.out.println("Eperisone");
                  System.out.println("Rp.19.000");
                  break;
            case "Entrostop" :
                  System.out.println("==================");
                  System.out.println("Entrostop");
                  System.out.println("Rp.24.000");
                  System.out.println("==================");
                  break;
            case "Furosemide" :
                  System.out.println("==================");
                  System.out.println("Acarbose");
                  System.out.println("Rp.9.000");
                  System.out.println("==================");
                  break;
            case "Fucoidan" :
                  System.out.println("==================");
                  System.out.println("Fucoidan");
                  System.out.println("Rp.13.000");
                  System.out.println("==================");
                  break;
            case "Gentamicin" :
                  System.out.println("==================");
                  System.out.println("Gentamicin");
                  System.out.println("Rp.23.000");
                  System.out.println("==================");
                  break;
            case "Gliserol" :
                  System.out.println("==================");
                  System.out.println("Gliserol");
                  System.out.println("Rp.28.000");
                  System.out.println("==================");
                  break;
            case "Heparin" :
                  System.out.println("==================");
                  System.out.println("Heparin");
                  System.out.println("Rp.24.000");
                  System.out.println("==================");
                  break;
            case "Indinavir" :
                  System.out.println("==================");
                  System.out.println("Indinavir");
                  System.out.println("Rp.98.000");
                  System.out.println("==================");
                  break;
             case "ketemine" :
                  System.out.println("==================");
                  System.out.println("ketemine");
                  System.out.println("Rp.24.000");
                  System.out.println("==================");
                  break;
            case "Ketamine" :
                  System.out.println("==================");
                  System.out.println("ketemine");
                  System.out.println("Rp.34.000");
                  System.out.println("==================");
                  break;
             case "Lanolin" :
                  System.out.println("==================");
                  System.out.println("Lanolin");
                  System.out.println("Rp.24.000");
                  System.out.println("==================");
                  break;
             case "Levodopa" :
                  System.out.println("==================");
                  System.out.println("Levodopa");
                  System.out.println("Rp.17.000");
                  System.out.println("==================");
                  break;                                                                                                             
            case "Manitol" :
                  System.out.println("==================");
                  System.out.println("Manitol");
                  System.out.println("Rp.18.000");
                  System.out.println("==================");
            case "Metildopa" :
                  System.out.println("==================");
                  System.out.println("Metildopa");
                  System.out.println("Rp.14.000");
                  System.out.println("==================");
                  break;                                                                                                             
             case "Morfin" :
                  System.out.println("==================");
                  System.out.println("Morfin");
                  System.out.println("Rp.11.000");
                  System.out.println("==================");
                  break;                                                                                                                            
            case "Nystatin" :
                  System.out.println("==================");
                  System.out.println("Nystatin");
                  System.out.println("Rp.24.000");
                  System.out.println("==================");
                  break;                                                                                                                            
           case "Orlistat" :
                  System.out.println("==================");
                  System.out.println("Orlistat");
                  System.out.println("Rp.12.000");
                  System.out.println("==================");
           case "Panadol" :
                  System.out.println("==================");
                  System.out.println("Panadol");
                  System.out.println("Rp.11.000");
                  System.out.println("==================");
                  break;                           
           case "Penesilin" :
                  System.out.println("==================");
                  System.out.println("Acarbose");
                  System.out.println("Rp.31.000");
                  System.out.println("==================");
                  break;     
            case "Petrolatum" :
                  System.out.println("==================");
                  System.out.println("Petrolatum");
                  System.out.println("Rp.31.000");
                  System.out.println("==================");
                  break;      
            case "Piracetam" :
                  System.out.println("==================");
                  System.out.println("Piracetam");
                  System.out.println("Rp.24.000");
                  System.out.println("==================");
                  break;  
            case "Ponstan" :
                  System.out.println("==================");
                  System.out.println("Ponstan");
                  System.out.println("Rp.21.000");
                  System.out.println("==================");
                  break;      
            case "Ramipril" :
                  System.out.println("==================");
                  System.out.println("Ramipril");
                  System.out.println("Rp.34.000");
                  System.out.println("==================");
                  break;            
            case "Senna" :
                  System.out.println("==================");
                  System.out.println("Senna");
                  System.out.println("Rp.23.000");
                  System.out.println("==================");
                  break;            
             case "Tamoxifen" :
                  System.out.println("==================");
                  System.out.println("Tamoxifen");
                  System.out.println("Rp.12.000");
                  System.out.println("==================");
                  break;
             case "Vitamin A" :
                  System.out.println("==================");
                  System.out.println("Acarbose");
                  System.out.println("Rp.3.000");
                  System.out.println("==================");
                  break;
             case "Vitamin C" :
                  System.out.println("==================");
                  System.out.println("Vitamin C");
                  System.out.println("Rp.4.000");
                  System.out.println("==================");
                  break;
            case "Vitamin D" :
                  System.out.println("==================");
                  System.out.println("Vitamin D");
                  System.out.println("Rp.5.000");
                  System.out.println("==================");
                  break  ;   
            case "Vitamin E" :
                  System.out.println("==================");
                  System.out.println("Vitamin E");
                  System.out.println("Rp.11.000");
                  System.out.println("==================");
                  break  ; 
            case "Vitamin K" :
                  System.out.println("==================");
                  System.out.println("Vitamin K");
                  System.out.println("Rp.6.000");
                  System.out.println("==================");
                  break  ;
            case"Keluar" :
                    System.exit(0);
                  break  ;
            default :
                    
                    
                  
        }
        }
    }
}
